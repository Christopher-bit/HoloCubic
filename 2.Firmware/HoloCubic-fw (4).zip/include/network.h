#ifndef NETWORK_H
#define NETWORK_H

#include <WiFi.h>
#include <HTTPClient.h>

 
class Network
{
private:
	 
public:
	void init(void);
	unsigned int getBilibiliFans(String url);
	String getWeather(void);
};
class WifiLib{
	public:
    char ssid[10][15]={
		"Christopher",
		"FAST_322E",
		"TP-LINK_EA16",
		"nuaa.wifi6"
	};
    char password[10][15]={
		"wsywsywsy",
		"20000606",
		"20000606",
		""
	};
};
#endif