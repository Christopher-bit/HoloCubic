FastLED updates for adafruit FEATHER M4 and fixes to ITSBITSY M4 compiles
  SAMD51

only tested on FEATHER M4 with DOTSTAR and neopixel strips
