C
^

Simple Drop down list
""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_dropdown/lv_ex_dropdown_1
  :language: c

Drop "up" list
""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_dropdown/lv_ex_dropdown_2
  :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
